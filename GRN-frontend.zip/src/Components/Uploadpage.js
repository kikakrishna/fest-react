import { useState } from 'react';
import './Uploadpage.css';
import Button from '@mui/material/Button';
import { TextField } from '@mui/material';
import { apiClient } from './Api';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Papa from 'papaparse';
import axios from 'axios';


function Uploadpage() {

    const [formData, setFormData] = useState({
        filename: '',
        file: '',
        Date: ''
    });
    const [filename, setfilename] = useState('');
    const [file, setfile] = useState('');
    const [Date, setDate] = useState('');
    const [selectedDate, setSelectedDate] = useState(null);
    const [data, setData] = useState([]);


    const handleSearch = async () => {
        console.log("searchentered");

        if (selectedDate) {
            try {
                const formattedDate = selectedDate.toISOString().split('T')[0]; // Format the date to YYYY-MM-DD
                // const response = await axios.get(`/fetch-data?date=${formattedDate}`);
                // setData(response.data.data); // Assuming response data has the structure as mentioned
                console.log("apihitted");
                // const formattedDate = selectedDate.toISOString().split('T')[0]; // Format the date to YYYY-MM-DD
                // const response = await axios.get(`/getbydate=${formattedDate}`);
                // console.log(response.data.data);
                apiClient()
                    .get(`/getbydate?date=${formattedDate}`, {

                        headers: { "Content-Type": "application/json" },

                    }).then((r) => {
                        console.log("analysticsresponse" + JSON.stringify(r.data.data));


                    });



            } catch (error) {
                console.error('Error fetching data:', error);




            }
        } else {
            // alert('Please select a date first');



            apiClient()
                .get("/getrows", {

                    headers: { "Content-Type": "application/json" },

                }).then((r) => {
                    console.log("analysticsresponse" + JSON.stringify(r.data.data));
                    setData(r.data.data);

                });
        }










    };


    const handleDateChange = (date) => {
        setSelectedDate(date);
    };


    const handleChangeFilename = (e) => {
        console.log(e.target.value);

        setfilename(e.target.value)
    };


    const handleChangeFile = (e) => {
        console.log(e.target.value);

        setfile(e.target.value)
    };

    const handleChangeDate = (e) => {
        console.log(e.target.value);

        setDate(e.target.value)
    };



    const handleChangeFileupload = (e) => {
        console.log("-----------------------", e.target.files[0]);

        setDate(e.target.files[0])

        console.log("date--------------------", Date);

        let filestore = {
            "file": e.target.files[0]
        }

        console.log("filestore--------------------", filestore);


        const formData = new FormData();
        formData.append('file', filestore);

        console.log("formdata--------------------", formData);

        apiClient()
            .post("/upload", filestore, {

                headers: { "Content-Type": "application/json" },

            }).then((r) => {
                console.log("analysticsresponse" + JSON.stringify(r.data.data));

                // var temparr = []
                // temparr.push(r.data.data)

                // temparr.flat()
                // console.log(temparr);
                // setValues(...temparr)
                // Values.flat()

                // console.log(r.data);
            });

    };


    const uploadfile = (e) => {

        let payload = {

            "filename": filename,
            "file": file,
            "Date": Date

        }
        console.log("dffrfrgfg----------", payload)



        apiClient()
            .post("/festupload", payload, {
                headers: { "Content-Type": "application/json" },

            }).then((r) => {
                console.log("analysticsresponse" + JSON.stringify(r.data.data));

                // var temparr = []
                // temparr.push(r.data.data)

                // temparr.flat()
                // console.log(temparr);
                // setValues(...temparr)
                // Values.flat()

                // console.log(r.data);
            });
    }


    const serachstyles = {
        "&.MuiButton-root": {
            border: "none",
            backgroundColor: '#273F57',
            borderRadius: '25px',
            padding: '4px 36px',
            color: "#green",
            marginTop: '10px'
        },
        "&.MuiButton-text": {
            color: "white"
        },
        "&.MuiButton-contained": {
            color: "yellow"
        },
        "&.MuiButton-outlined": {
            color: "brown"
        }
    };


    const inputbox = {
        "&.MuiInputBase-input": {
            border: "none",
            backgroundColor: '#fff',
            borderRadius: '25px',
            padding: '4px 36px',
            color: "#green",
        },

        "&.MuiTextField-root": {
            backgroundColor: "white",
            border: "none",
            borderRadius: "10px",
            marginRight: '20px'
        },
        "&.MuiInputBase-text": {
            color: "white"
        },
        "&.MuiInputBase-contained": {
            color: "yellow"
        },
        "&.MuiInputBase-outlined": {
            color: "brown"
        }
    };

    const [jsonData, setJsonData] = useState(null);
    const [error, setError] = useState(null);

    const handleFileUpload = (event) => {
        const file = event.target.files[0];

        if (file) {
            Papa.parse(file, {
                header: true, // Use first row as header
                dynamicTyping: true, // Automatically convert types
                complete: (result) => {
                    // Convert CSV to JSON
                    setJsonData(result.data);

                    setError(null);
                    console.log("data------------>", result.data);

                    let payload =
                    {
                        "data": result.data
                    }
                    apiClient()
                        .post("/poupload", payload, {

                            headers: { "Content-Type": "application/json" },

                        }).then((r) => {
                            console.log("analysticsresponse" + JSON.stringify(r.data.data));
                            setData(r.data.data);

                        });
                },
                error: (parseError) => {
                    setError(`Error parsing file: ${parseError.message}`);
                    setJsonData(null);
                },
            });
        }
    };


    return (

        <div className="container">




            <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
            />
            {/* {error && <p style={{ color: 'red' }}>{error}</p>}
            {jsonData && (
                <pre>{JSON.stringify(jsonData, null, 2)}</pre>
            )} */}






            {/* <div className=''> */}
            {/* <div className='uploadsection'>
                

                <TextField sx={inputbox} label="File name" variant="outlined" value={formData.Filename} onChange={handleChangeFilename} />
                <TextField sx={inputbox} label="Date" variant="outlined" onChange={handleChangeDate} />
                <TextField sx={inputbox} label="UploadFile" variant="outlined" onChange={handleChangeFile} />

                <input label="" variant="outlined" type='file' accept=".xls, .xlsx" onChange={handleChangeFileupload} />

              

                <div className='searchbtn'>
                    <Button sx={serachstyles} onClick={uploadfile}>Import</Button>

                </div>
                <br />

            </div> */}



            {/* Date picker start */}

            <h1 style={{marginBottom :"25px", marginTop :"25px"}}>Fetch Data by Date</h1>
            <DatePicker
                selected={selectedDate}
                onChange={handleDateChange}
                dateFormat="yyyy-MM-dd"
                placeholderText="Select a date"
            />
            <button onClick={handleSearch} style={{marginLeft :"25px"}}>Search</button>

            <div className='showtable' style={{marginTop :"25px"}}>
                {data.length > 0 ? (
                    <table border="1">
                        <thead>
                            <tr className='table-header'>
                                <th>ID</th>
                                <th>Inbound No</th>
                                <th>PO No</th>
                                {/* <th>Created Date</th> */}
                                <th>Invoice No</th>
                                <th>SKU Code</th>
                                <th>SKU Name</th>
                                <th>Received Qty</th>
                                <th>expected_qty</th>

                                <th>vendor_code</th>
                                <th>inbound_line_no</th>
                                <th>lot_code</th>
                                <th>grn_value_without_tax</th>
                                <th>lot_mrp</th>

                                {/* Add other headers as per your data structure */}
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((row) => (
                                <tr className='table-header' key={row.id}>
                                    <td>{row.id}</td>
                                    <td>{row.inbound_no}</td>
                                    <td>{row.po_no}</td>
                                    {/* <td>{new Date(row.created_date).toLocaleDateString()}</td> */}
                                    <td>{row.invoice_no}</td>
                                    <td>{row.sku_code}</td>
                                    <td>{row.sku_name}</td>
                                    <td>{row.received_qty}</td>
                                    <td>{row.expected_qty}</td>

                                    <td>{row.vendor_code}</td>
                                    <td>{row.inbound_line_no}</td>
                                    <td>{row.lot_code}</td>
                                    <td>{row.grn_value_without_tax}</td>
                                    <td>{row.lot_mrp}</td>


                                    {/* Add other rows as per your data structure */}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <p>No data found for the selected date</p>
                )}
            </div>

        </div>
    );
}

export default Uploadpage;
